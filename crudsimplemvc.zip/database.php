<?php
class Database{
	public $con;
	public function __construct(){
		$this->con = mysqli_connect("localhost", "root", "", "crud");
		if (!$this->con) {
			die('failed to connect db');
		}
	}
}

$obj = new Database;