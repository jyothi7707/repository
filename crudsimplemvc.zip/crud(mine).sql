-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2019 at 06:40 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `study` varchar(20) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `aboutyou` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`user_id`, `name`, `phone`, `email`, `study`, `photo`, `aboutyou`, `date`) VALUES
(1, 'AB UTNAL', '', 'utnal.ab@gmail.com', '', 'ab.jpg', '', '2018-12-26 17:14:44'),
(2, 'MyJyo', '8722222996', 'utnal.ab@gmail.com', '', 'avatar.jpg', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2018-12-14 09:10:42'),
(3, 'AB', '8722222996', 'jyothidodamani@gmail.com', '', '5re.jpg', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2018-12-26 17:16:33'),
(4, 'Mabb Jyo', '7204771458', 'jyothidodamani@gmail.com', '', '1e.jpg', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2018-12-26 16:52:44'),
(9, 'aray', '', 'b@gmail.com', '', 'discount.jpg', '', '2019-09-21 10:09:39'),
(10, 'xz', '', 'zcz', '', 'IMG-20190422-WA0021.jpg', '', '2019-09-21 10:11:30'),
(11, 'pooja1', '', 'ndjndjnd1', 'mca1', 'discount.jpg', '', '2019-09-21 10:41:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
